# $ZCONFDIR/plugins.zsh
# Requires: zsh-defer (available after post.zsh / init.zsh)

# Caches stdout of an initializer; invalidates when binary changes.
_cached_eval() {
  local cache="$ZCACHEDIR/eval_${1:t}.zsh"
  local bin; bin=$(whence -p "$1" 2>/dev/null)
  if [[ ! -s $cache || ( -n $bin && $cache -ot $bin ) ]]; then
    mkdir -p "${cache:h}"
    "$@" >| "$cache" 2>/dev/null || { rm -f "$cache"; return 1 }
  fi
  builtin source "$cache"
}

# ── FZF global defaults ───────────────────────────────────────────────────────
# Use fd instead of find for Ctrl+T and Alt+C: respects .gitignore, faster.
export FZF_DEFAULT_COMMAND='fd --type f --hidden --exclude .git'
export FZF_CTRL_T_COMMAND='fd --type f --hidden --exclude .git'
export FZF_ALT_C_COMMAND='fd --type d --hidden --exclude .git'

# Global fzf appearance and behaviour
export FZF_DEFAULT_OPTS="\
  --height=60% \
  --layout=reverse \
  --border=rounded \
  --info=inline \
  --bind=ctrl-space:toggle+down \
  --bind=ctrl-a:toggle-all \
  --bind=ctrl-/:toggle-preview"

# Ctrl+T: preview files with bat, directories with eza
export FZF_CTRL_T_OPTS="\
  --preview='[[ -d {} ]] && eza --tree --level=2 --color=always --icons=auto {} || bat --style=numbers --color=always --line-range=:100 {}' \
  --preview-window=right:55%:wrap"

# Alt+C: tree preview with eza
export FZF_ALT_C_OPTS="\
  --preview='eza --tree --level=2 --color=always --icons=auto {}' \
  --preview-window=right:55%"

# Smart _fzf_comprun: command-aware fzf completions for ** triggers
_fzf_comprun() {
  local command=$1; shift
  case "$command" in
    cd)           fzf --preview 'eza --tree --level=2 --color=always --icons=auto {}' "$@" ;;
    ssh)          fzf --preview 'dig {} 2>/dev/null | head -20' "$@" ;;
    export|unset) fzf --preview "eval 'echo \${}'" "$@" ;;
    nvim|vim)     fzf --preview 'bat --style=numbers --color=always --line-range=:100 {}' "$@" ;;
    kill)         fzf --preview 'ps --pid={} -o pid,user,cmd --no-headers -w' "$@" ;;
    *)            fzf --preview '[[ -d {} ]] && eza --tree --color=always {} || bat --style=numbers --color=always --line-range=:100 {}' "$@" ;;
  esac
}

# ── Starship ──────────────────────────────────────────────────────────────────
# Synchronous: must register its precmd hook before the first prompt renders.
command -v starship &>/dev/null \
  || curl -sS https://starship.rs/install.sh | sh -s -- --yes --bin-dir "$HOME/.local/bin"
# export STARSHIP_CONFIG=$ZCONFDIR/themes/starship.toml
_cached_eval starship init zsh

# ── Zoxide ────────────────────────────────────────────────────────────────────
zsh-defer -c '_cached_eval zoxide init zsh'

# ── Atuin ─────────────────────────────────────────────────────────────────────
# --disable-up-arrow: let zsh-history-substring-search own up arrow for prefix
# search. Atuin handles Ctrl+R with its neural ranking and sync.
# Remove --disable-up-arrow if you prefer atuin's smarter up-arrow search.
zsh-defer -c '_cached_eval atuin init zsh --disable-up-arrow'

# ── you-should-use config ─────────────────────────────────────────────────────
# export YSU_MESSAGE_POSITION="after"
# export YSU_MODE=ALL
# export YSU_HARDCORE=0

# PATH rehash once asynchronously — far cheaper than per-tab rehash
zsh-defer rehash
