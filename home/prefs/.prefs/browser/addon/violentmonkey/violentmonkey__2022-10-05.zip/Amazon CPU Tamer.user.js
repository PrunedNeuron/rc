

    // ==UserScript==
    // @name        Amazon CPU Tamer
    // @name:ja     Amazon CPU Tamer
    // @name:zh-CN  Amazon CPU Tamer
    // @namespace   knoa.jp
    // @description It reduces CPU usage on Amazon shopping pages. Enjoy your snappy shopping.
    // @description:ja AmazonのショッピングページでのCPU使用率を削減します。お買いものをサクサク楽しみましょう。
    // @description:zh-CN 减少Amazon购物页面上的CPU利用率。顺利地享受买东西吧。
    // @include     https://www.amazon.com/*
    // @include     https://www.amazon.co.jp/*
    // @include     https://www.amazon.co.uk/*
    // @include     https://www.amazon.es/*
    // @include     https://www.amazon.fr/*
    // @include     https://www.amazon.de/*
    // @include     https://www.amazon.it/*
    // @include     https://www.amazon.*
    // @include     https://*.amazon-*.com/*
    // @include     https://*.*-amazon.com/*
    // @exclude     */cart/*
    // @exclude     */buy/*
    // @version     1.4.4
    // @grant       none
    // @run-at      document-start
    // @antifeature referral-link This script may add an associate ID to visited Amazon URLs. It doesn't replace any existed ID. Thank you.
    // @antifeature:ja referral-link ありがとうございます。本スクリプトは、訪れたAmazonページのURLにアソシエイトIDを付与することがあります。別のIDがすでに付与されている場合は、置き換えることはしません。
    // @antifeature:zh-CN referral-link 本脚本可能会为访问过的Amazon页面的URL授予联盟ID。如果已经授予了另一个ID，则不会进行替换。谢谢。
    // @contributionURL https://paypal.me/kantankikaku
    // ==/UserScript==
    (function(){
      const SCRIPTID = 'AmazonCpuTamer';
      console.log(SCRIPTID, location.href);
      const BUNDLEDINTERVAL    =     125;/* the bundled interval */
      const BACKGROUNDINTERVAL = 60*1000;/* take even longer interval on hidden tab */
      const IFRAMETIMEOUT      =  1*1000;/* amazon uses timeouts instead of intervals on iframes */
      /*
        [interval]
        tame quick intervals
      */
      if(window === top){
        /* integrate each of intervals */
        const bundle = {};/* {0: {f, interval, lastExecution}} */
        let index = 0;/* use it instead of interval id */
        let lastExecution = 0;
        /* bundle intervals */
        const originalSetInterval = window.setInterval.bind(window);
        window.setInterval = function(f, interval, ...args){
          //console.log(SCRIPTID, 'original interval:', interval, location.href);
          bundle[index] = {
            f: f.bind(null, ...args),
            interval: interval,
            lastExecution: 0,
          };
          return index++;
        };
        window.clearInterval = function(id){
          //console.log(SCRIPTID, 'clearInterval:', id, location.href);
          delete bundle[id];
        };
        /* execute bundled intervals */
        /* a bunch of intervals does cost so much even if the processes do nothing */
        originalSetInterval(function(){
          const now = Date.now();
          if(document.hidden && now < lastExecution + BACKGROUNDINTERVAL) return;
          Object.keys(bundle).forEach(id => {
            const item = bundle[id];
            if(item === undefined) return;/* it could be occur on tiny deletion chance */
            if(now < item.lastExecution + item.interval) return;/* not yet */
            item.f();
            item.lastExecution = now;
          });
          lastExecution = now;
        }, BUNDLEDINTERVAL);
      }
      /*
        [timeout]
        tame quick timeouts on iframe ads
      */
      if(window !== top){
        const originalSetTimeout = window.setTimeout.bind(window);
        window.setTimeout = function(f, timeout, ...args){
          if(document.hidden) return;
          if(timeout < IFRAMETIMEOUT){
            //console.log(SCRIPTID, 'timeout:', timeout, 'to', IFRAMETIMEOUT, location.href);
            timeout = IFRAMETIMEOUT;
          }
          return originalSetTimeout(f, timeout, ...args);
        };
      }
    })();
